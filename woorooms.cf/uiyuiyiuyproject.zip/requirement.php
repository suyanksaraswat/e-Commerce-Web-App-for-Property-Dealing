categ type
owner agent
sell,rent,pg/hostel,find rom mate
title
location(state,city,locality,loc)
sell:area
rent:price per month ,dep
terms condn


Ammenitis:
wifi
car park
24 hr water
power backup
swiming pool
gym
garden
temple


find room-mate
nature
smoking
drinking
studnt,working