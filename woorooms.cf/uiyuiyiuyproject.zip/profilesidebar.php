<div class="widget widget-sidebar widget-white">
    <div class="widget-header">
        <h3>MY ACCOUNT</h3>
    </div>    
    <ul class="list-check">
        <li><a href="profile.php">My Profile</a>&nbsp;</li>
        <li><a href="my_listing.php">My Listing</a>&nbsp;</li>
        <li><a href="setting.php">Setting</a>&nbsp;</li>  
    </ul>
 </div>