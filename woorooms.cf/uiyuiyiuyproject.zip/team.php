<?php
	include_once('config.php');
?>
<?php
	include_once('header.php');
	
?>
<?php
	include_once('nav.php');
?>
<div id="header" class="heading" style="background-image: url(img/img01.jpg);">
      <div class="container">
        <div class="row">
          <div class="col-md-10 col-md-offset-1 col-sm-12">
            <div class="page-title">
              <h2>Team</p>
            </div>
            <ol class="breadcrumb">
              <li><a href="index.php">Home</a></li>
              <li class="active">Team</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
<?php
	include_once('footer.php');
?>